import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),base='https://cdn.jsdelivr.net/npm/three@0.169.0/';
const target=path.join(root,'assets/vendor/three'),temp=target+'.partial';
const roots=['build/three.module.js','examples/jsm/controls/OrbitControls.js','examples/jsm/postprocessing/EffectComposer.js','examples/jsm/postprocessing/RenderPass.js','examples/jsm/postprocessing/UnrealBloomPass.js','examples/jsm/postprocessing/OutputPass.js','examples/jsm/utils/BufferGeometryUtils.js','LICENSE'];
const visited=new Set(),hashes={};
async function download(relative){
 const url=new URL(relative,base);if(!url.href.startsWith(base)||url.search||url.hash)throw Error('Dependency escapes pinned package');
 relative=decodeURIComponent(url.href.slice(base.length));if(visited.has(relative))return;visited.add(relative);if(visited.size>150)throw Error('Dependency limit exceeded');
 const response=await fetch(url,{signal:AbortSignal.timeout(30000)});if(!response.ok)throw Error('HTTP '+response.status+' '+url.href);
 const data=new Uint8Array(await response.arrayBuffer());if(data.length>5000000)throw Error('Dependency exceeds size limit');
 const text=new TextDecoder().decode(data);if(relative.endsWith('.js')&&text.trimStart().startsWith('<'))throw Error('HTML instead of JavaScript');
 const dest=path.join(temp,relative);if(!dest.startsWith(temp+path.sep))throw Error('Invalid dependency path');await fs.mkdir(path.dirname(dest),{recursive:true});await fs.writeFile(dest,data);hashes[relative]=createHash('sha256').update(data).digest('hex');
 if(relative.endsWith('.js'))for(const m of text.matchAll(/\b(?:import|export)\s+(?:[^'";]*?\s+from\s*)?['"]([^'"]+)['"]/g)){
  if(m[1]==='three')continue;if(!m[1].startsWith('.'))throw Error('Unsupported import '+m[1]);
  const next=new URL(m[1],url);if(!next.href.startsWith(base))throw Error('Dependency escapes package');await download(next.href.slice(base.length));
 }
}
await fs.rm(temp,{recursive:true,force:true});await fs.mkdir(temp,{recursive:true});
try{
 for(const name of roots)await download(name);
 await fs.writeFile(path.join(temp,'checksums.json'),JSON.stringify({package:'three',version:'0.169.0',files:hashes},null,2));
 // Keep the old directory until the complete graph has been retrieved successfully.
 const backup=target+'.previous';await fs.rm(backup,{recursive:true,force:true});
 try{await fs.rename(target,backup);}catch(e){if(e.code!=='ENOENT')throw e;}
 try{await fs.rename(temp,target);}catch(e){try{await fs.rename(backup,target);}catch(_){}throw e;}
 await fs.writeFile(path.join(root,'site-config.json'),JSON.stringify({localThree:true},null,2)+'\n');await fs.rm(backup,{recursive:true,force:true});
 console.log('Three.js 0.169.0 files ready:',visited.size);
}catch(error){await fs.rm(temp,{recursive:true,force:true});throw error;}
