/* Static Pages bootstrap. All site-local URLs are relative to this module. */
const $=id=>document.getElementById(id);
let failed=false,ready=false;
function showFailure(message){
 failed=true;const loader=$('loader');if(!loader)return;loader.style.display='flex';loader.style.opacity='1';
 $('loadingText').textContent=String(message||'Не удалось запустить сцену.');
 loader.querySelector('.loadline').hidden=true;$('startupActions').hidden=false;
 $('startupStatus').textContent='Сцена не запущена';
}
window.aquariumFail=showFailure;
$('retry').addEventListener('click',()=>location.reload());
$('retryLow').addEventListener('click',()=>{const u=new URL(location.href);u.searchParams.set('quality','low');location.assign(u);});
window.addEventListener('nacre:ready',()=>{ready=true;failed=false;clearTimeout(window.loadTimer);$('startupStatus').textContent='Сцена загружена';});
window.addEventListener('error',e=>{if(!ready)showFailure('Ошибка запуска: '+(e.message||'не удалось загрузить ресурс'));});
window.addEventListener('unhandledrejection',e=>{console.error('NACRE:',e.reason);if(!ready)showFailure('Ошибка запуска: '+String(e.reason?.message||e.reason));});
window.loadTimer=setTimeout(()=>{if(!ready)showFailure('Загрузка заняла слишком много времени. Проверьте доступ к CDN и попробуйте повторить.');},25000);
if(location.protocol==='file:'){
 showFailure('Эта сборка использует ES-модули. Откройте сайт через GitHub Pages или локальный HTTP-сервер: python -m http.server 8000.');clearTimeout(window.loadTimer);
}else{
 try{await import('./aquarium.mjs');if(!window.aquariumReady&&!failed)showFailure('Сцена не сообщила о готовности.');}
 catch(error){clearTimeout(window.loadTimer);console.error('NACRE startup:',error);showFailure('Не удалось загрузить 3D. Проверьте доступ к CDN Three.js и поддержку WebGL 2. Можно повторить запуск в экономичном режиме.');}
}
