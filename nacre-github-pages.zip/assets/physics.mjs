/* Numerical utilities shared by the aquarium and executable unit tests. */
const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
const lerp=(a,b,t)=>a+(b-a)*t;
export class WaveField{
 constructor(nx=101,nz=65){if(!Number.isInteger(nx)||!Number.isInteger(nz)||nx<3||nz<3||nx>257||nz>257)throw new RangeError('Invalid wave grid');this.nx=nx;this.nz=nz;this.dx=24/(nx-1);this.dz=15/(nz-1);this.h=new Float32Array(nx*nz);this.v=new Float32Array(nx*nz);this.nextV=new Float32Array(nx*nz);this.foam=new Float32Array(nx*nz);this.time=0;this.impacts=0;}
 sample(x,z,array=this.h){if(!Number.isFinite(x)||!Number.isFinite(z))return 0;const fx=clamp((x+12)/this.dx,0,this.nx-1),fz=clamp((z+7.5)/this.dz,0,this.nz-1),ix=Math.min(this.nx-2,Math.floor(fx)),iz=Math.min(this.nz-2,Math.floor(fz)),a=fx-ix,b=fz-iz,i=iz*this.nx+ix;return lerp(lerp(array[i],array[i+1],a),lerp(array[i+this.nx],array[i+this.nx+1],a),b);}
 kick(x,z,velocity=.7,radius=.4,foam=0){if(![x,z,velocity,radius,foam].every(Number.isFinite)||radius<=0||foam<0)return false;if(Math.abs(x)>12||Math.abs(z)>7.5)return;const n=this.nx,m=this.nz,r=Math.max(radius,Math.max(this.dx,this.dz)*.8),ix0=Math.max(0,Math.floor((x-3*r+12)/this.dx)),ix1=Math.min(n-1,Math.ceil((x+3*r+12)/this.dx)),iz0=Math.max(0,Math.floor((z-3*r+7.5)/this.dz)),iz1=Math.min(m-1,Math.ceil((z+3*r+7.5)/this.dz));for(let iz=iz0;iz<=iz1;iz++)for(let ix=ix0;ix<=ix1;ix++){const xx=ix*this.dx-12-x,zz=iz*this.dz-7.5-z,q=(xx*xx+zz*zz)/(r*r),g=Math.exp(-q*.5),i=iz*n+ix;this.v[i]=clamp(this.v[i]+velocity*(1-q*.5)*g,-3,3);this.foam[i]=Math.min(1,this.foam[i]+foam*g);}this.impacts++;}
 advance(dt,wind=0){if(!Number.isFinite(dt)||dt<0||dt>.1||!Number.isFinite(wind)||Math.abs(wind)>5)throw new RangeError('Invalid wave step');if(dt===0)return;const steps=Math.ceil(dt/(1/120)),ds=dt/steps,n=this.nx,m=this.nz,idx2=1/(this.dx*this.dx),idz2=1/(this.dz*this.dz),c2=2.55*2.55,damp=Math.exp(-.42*ds),fade=Math.exp(-1.1*ds);for(let k=0;k<steps;k++){this.time+=ds;const t=this.time,h=this.h,v=this.v,nv=this.nextV;for(let iz=0;iz<m;iz++)for(let ix=0;ix<n;ix++){const i=iz*n+ix,l=ix?i-1:i,r=ix<n-1?i+1:i,b=iz?i-n:i,f=iz<m-1?i+n:i,lap=(h[l]+h[r]-2*h[i])*idx2+(h[b]+h[f]-2*h[i])*idz2;const x=ix*this.dx-12,z=iz*this.dz-7.5,force=wind*.018*(Math.sin(x*.8+z*.45-t*1.45)+.55*Math.sin(x*1.35-z*.7+t*1.8));nv[i]=(v[i]+(c2*lap+force)*ds)*damp;this.foam[i]=Math.max(this.foam[i]*fade,Math.min(.6,Math.max(0,Math.abs(nv[i])-.8)*.04));}for(let i=0;i<h.length;i++){v[i]=nv[i];h[i]+=v[i]*ds;if(Math.abs(h[i])>.18){h[i]=clamp(h[i],-.18,.18);v[i]*=.32;}}}}
 energy(){let e=0;for(let z=0;z<this.nz;z++)for(let x=0;x<this.nx;x++){const i=z*this.nx+x,gx=x<this.nx-1?(this.h[i+1]-this.h[i])/this.dx:0,gz=z<this.nz-1?(this.h[i+this.nx]-this.h[i])/this.dz:0;e+=.5*this.v[i]**2+.5*2.55**2*(gx*gx+gz*gz);}return e*this.dx*this.dz;}
}

// Inputs are in the collider's local coordinate system. This tests the actual
// finite cylinder (side and caps), not an ellipsoidal approximation to it.
export function segmentHitsSolid(x,y,z,dx,dy,dz,c,tMin=.015,tMax=.97){
 if(![x,y,z,dx,dy,dz,c.rx,c.ry,c.rz,tMin,tMax].every(Number.isFinite)||c.rx<=0||c.ry<=0||c.rz<=0||tMax<tMin)return false;
 const interval=(A,B,C)=>{
  if(A<1e-15)return C<=0?[-Infinity,Infinity]:null;
  const disc=B*B-4*A*C;if(disc<0)return null;
  const root=Math.sqrt(Math.max(0,disc));return[(-B-root)/(2*A),(-B+root)/(2*A)];
 };
 let range;
 if(c.kind==='cylinder'){
  range=interval(dx*dx+dz*dz,2*(x*dx+z*dz),x*x+z*z-c.rx*c.rx);if(!range)return false;
  if(Math.abs(dy)<1e-15){if(Math.abs(y)>c.ry)return false;}
  else{const a=(-c.ry-y)/dy,b=(c.ry-y)/dy;range[0]=Math.max(range[0],Math.min(a,b));range[1]=Math.min(range[1],Math.max(a,b));}
 }else{
  x/=c.rx;y/=c.ry;z/=c.rz;dx/=c.rx;dy/=c.ry;dz/=c.rz;
  range=interval(dx*dx+dy*dy+dz*dz,2*(x*dx+y*dy+z*dz),x*x+y*y+z*z-1);if(!range)return false;
 }
 return Math.max(tMin,range[0])<=Math.min(tMax,range[1]);
}
