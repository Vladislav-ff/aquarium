import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import {WaveField,segmentHitsSolid,FixedStepper} from '../src/physics.mjs';
const ell={kind:'ellipsoid',rx:2,ry:1,rz:3},cyl={kind:'cylinder',rx:1,ry:2,rz:1};
test('Invalid wave grids rejected',()=>{for(const n of [0,1,2,258,3.5,NaN])assert.throws(()=>new WaveField(n,3));});
test('Still water remains still',()=>{const w=new WaveField(17,13);for(let i=0;i<100;i++)w.advance(1/60);assert.equal(w.energy(),0);});
test('Zero step and invalid steps handled',()=>{const w=new WaveField(17,13);w.advance(0);assert.equal(w.time,0);for(const n of [-1,NaN,Infinity,.2])assert.throws(()=>w.advance(n));});
test('Impulse creates finite energy',()=>{const w=new WaveField(33,21);w.kick(0,0,.7,.6,.2);assert.ok(w.energy()>0);for(let i=0;i<120;i++)w.advance(1/60);assert.ok(w.h.every(Number.isFinite));assert.ok(w.v.every(Number.isFinite));});
test('Invalid impulses cannot poison the grid',()=>{const w=new WaveField(17,13);for(const a of [[NaN,0],[0,Infinity],[0,0,NaN],[0,0,1,-1]])w.kick(...a);assert.equal(w.energy(),0);});
test('Wall impulse remains bounded',()=>{const w=new WaveField(33,21);w.kick(11.9,7.4,3,.4,.5);for(let i=0;i<300;i++)w.advance(1/60,.4);assert.ok(w.h.every(x=>Number.isFinite(x)&&Math.abs(x)<.180001));});
test('Energy dissipates in calm water',()=>{const w=new WaveField(33,21);w.kick(0,0,1,.8);const e=w.energy();for(let i=0;i<900;i++)w.advance(1/60);assert.ok(w.energy()<e*.1);});
test('Grid sampling handles bounds and NaN',()=>{const w=new WaveField(5,5);w.h.fill(.1);assert.ok(Math.abs(w.sample(1000,1000)-.1)<1e-6);assert.equal(w.sample(NaN,0),0);});
test('Ellipsoid crossing blocks target',()=>assert.ok(segmentHitsSolid(-4,0,0,8,0,0,ell)));
test('Above ellipsoid is clear',()=>assert.equal(segmentHitsSolid(-4,3,0,8,0,0,ell),false));
test('Origin inside ellipsoid is detected',()=>assert.ok(segmentHitsSolid(0,0,0,4,0,0,ell)));
test('Collider beyond endpoint does not block',()=>assert.equal(segmentHitsSolid(-5,0,0,1,0,0,ell),false));
test('Cylinder cap corners are not ellipsoid gaps',()=>assert.ok(segmentHitsSolid(-2,1.9,0,4,0,0,cyl)));
test('Above finite cylinder is clear',()=>assert.equal(segmentHitsSolid(-2,2.1,0,4,0,0,cyl),false));
test('Vertical cylinder segment hits caps',()=>assert.ok(segmentHitsSolid(.8,-4,0,0,8,0,cyl)));
test('Vertical segment outside radius is clear',()=>assert.equal(segmentHitsSolid(1.1,-4,0,0,8,0,cyl),false));
test('Degenerate segments handled',()=>{assert.ok(segmentHitsSolid(0,0,0,0,0,0,cyl));assert.equal(segmentHitsSolid(3,0,0,0,0,0,cyl),false);});
test('Invalid collider dimensions rejected',()=>assert.equal(segmentHitsSolid(0,0,0,1,0,0,{kind:'cylinder',rx:0,ry:1,rz:1}),false));
test('Fixed stepper rejects invalid setup',()=>{assert.throws(()=>new FixedStepper(0));assert.throws(()=>new FixedStepper(.01,0));});
test('Frame partition does not alter step count',()=>{const a=new FixedStepper(),b=new FixedStepper();let x=0,y=0;for(let i=0;i<60;i++)a.advance(1/60,false,()=>x++);for(let i=0;i<30;i++)b.advance(1/30,false,()=>y++);assert.equal(x,60);assert.equal(x,y);});
test('Pause drops accumulated partial time',()=>{const f=new FixedStepper();let n=0;f.advance(.01,false,()=>n++);f.advance(20,true,()=>n++);assert.equal(n,0);assert.equal(f.acc,0);});
test('Long frame has a bounded work budget',()=>{const f=new FixedStepper();let n=0;f.advance(10,false,()=>n++);assert.equal(n,6);assert.ok(f.dropped>9);});
test('Resume does not catch up paused wall time',()=>{const f=new FixedStepper();f.advance(100,true,()=>{});let n=0;f.advance(1/60,false,()=>n++);assert.equal(n,1);});
test('Invalid elapsed time rejected',()=>{const f=new FixedStepper();for(const t of [-1,NaN,Infinity])assert.throws(()=>f.advance(t,false,()=>{}));});
// Exercise the exact delivered narrow-phase code with a minimal numerical fixture.
// This fixture does not test or emulate the complete Three.js renderer.
class V{
 constructor(x=0,y=0,z=0){this.set(x,y,z);}set(x,y,z){this.x=x;this.y=y;this.z=z;return this;}copy(v){return this.set(v.x,v.y,v.z);}multiplyScalar(k){this.x*=k;this.y*=k;this.z*=k;return this;}length(){return Math.hypot(this.x,this.y,this.z);}
 applyQuaternion(q){const{x,y,z}=this,tx=2*(q.y*z-q.z*y),ty=2*(q.z*x-q.x*z),tz=2*(q.x*y-q.y*x);this.x=x+q.w*tx+q.y*tz-q.z*ty;this.y=y+q.w*ty+q.z*tx-q.x*tz;this.z=z+q.w*tz+q.x*ty-q.y*tx;return this;}
}
const source=fs.readFileSync(new URL('../src/aquarium.mjs',import.meta.url),'utf8');
const code=source.slice(source.indexOf('function sphereStaticContact('),source.indexOf('function resolveEnvironment('));
const ctx={Math,clamp:(v,a,b)=>Math.max(a,Math.min(b,v)),contactPoint:new V(),contactNormal:new V(),contactPush:new V()};vm.createContext(ctx);vm.runInContext(code,ctx);
const id={x:0,y:0,z:0,w:1},solid=kind=>({kind,x:0,y:0,z:0,rx:1,ry:1,rz:1,q:id,invQ:id});
test('Separated sphere does not collide',()=>assert.equal(ctx.sphereStaticContact(3,0,0,.2,solid('ellipsoid')),0));
test('Ellipsoid correction points outwards',()=>{assert.ok(ctx.sphereStaticContact(1.1,0,0,.2,solid('ellipsoid'))>0);assert.ok(ctx.contactPush.x>0);});
test('Coincident center has finite correction',()=>{ctx.sphereStaticContact(0,0,0,.2,solid('ellipsoid'));assert.ok(Number.isFinite(ctx.contactPush.length()));assert.ok(ctx.contactPush.length()>1);});
test('Cylinder cap produces vertical correction',()=>{ctx.sphereStaticContact(0,.95,0,.2,solid('cylinder'));assert.ok(ctx.contactPush.y>0);assert.ok(Math.abs(ctx.contactPush.x)<1e-8);});
test('Quaternion rotation transforms contact normal',()=>{const c=solid('ellipsoid'),a=Math.PI/4;c.q={x:0,y:0,z:Math.sin(a),w:Math.cos(a)};c.invQ={x:0,y:0,z:-Math.sin(a),w:Math.cos(a)};ctx.sphereStaticContact(0,1.1,0,.2,c);assert.ok(ctx.contactPush.y>0);});
test('Contact buffers can grow beyond 80',()=>{const a=source.indexOf('let contactParents='),b=source.indexOf('// ── Fish anatomy',a),sandbox={Int32Array,Uint8Array,Math,fish:Array.from({length:130},()=>({})),telemetry:{}};vm.createContext(sandbox);vm.runInContext(source.slice(a,b)+';beginContacts();joinContacts(129,128);this.same=contactRoot(129)===contactRoot(128);this.n=contactParents.length;',sandbox);assert.ok(sandbox.same);assert.ok(sandbox.n>=130);});
test('Delivered app uses tested fixed-step scheduler',()=>{assert.ok(source.includes('new FixedStepper(1/60,6)'));assert.equal(source.includes('const step=state.low?'),false);});
test('Visibility/BFCache handlers both reset and reschedule',()=>{assert.ok(source.includes("on(document,'visibilitychange'"));assert.ok(source.includes("on(window,'pageshow'"));assert.ok(source.includes('function scheduleFrame()'));});

// Validate the optional vendor tool using a LOCAL synthetic dependency graph.
// No real Three.js code is downloaded or represented by these fixtures.
import os from 'node:os';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
function vendorFixture(mode){
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'nacre-vendor-'));
 fs.mkdirSync(path.join(dir,'scripts'),{recursive:true});fs.copyFileSync(new URL('../scripts/vendor-three.mjs',import.meta.url),path.join(dir,'scripts/vendor-three.mjs'));
 fs.mkdirSync(path.join(dir,'assets/vendor/three'),{recursive:true});fs.writeFileSync(path.join(dir,'assets/vendor/three/old-marker'),'keep');
 const code=`globalThis.fetch=async function(input){const url=String(input),base='https://cdn.jsdelivr.net/npm/three@0.169.0/';if(!url.startsWith(base))throw Error('Unexpected fetch');const p=url.slice(base.length);if(${JSON.stringify(mode)}==='fail'&&p==='examples/jsm/controls/OrbitControls.js')return new Response('no',{status:503});let text=p==='LICENSE'?'Fixture license':'export const fixture=true;';if(p==='build/three.module.js')text=${JSON.stringify(mode)}==='escape'?"export * from '../../escape.js';":"export * from './three.core.js';";if(p.startsWith('examples/jsm/postprocessing/'))text="import {x} from '../shaders/Fixture.js'; export const fixture=true;";return new Response(text,{status:200});};`;
 fs.writeFileSync(path.join(dir,'mock-fetch.mjs'),code);
 const result=spawnSync(process.execPath,['--import',path.join(dir,'mock-fetch.mjs'),path.join(dir,'scripts/vendor-three.mjs')],{encoding:'utf8',timeout:15000});
 return {dir,result,clean:()=>fs.rmSync(dir,{recursive:true,force:true})};
}
test('Vendor recursively retrieves only the pinned synthetic graph',()=>{const f=vendorFixture('ok');try{assert.equal(f.result.status,0,f.result.stderr);const c=JSON.parse(fs.readFileSync(path.join(f.dir,'assets/vendor/three/checksums.json'),'utf8'));assert.ok(c.files['build/three.core.js']);assert.ok(c.files['examples/jsm/shaders/Fixture.js']);assert.ok(c.files.LICENSE);assert.equal(JSON.parse(fs.readFileSync(path.join(f.dir,'site-config.json'))).localThree,true);assert.equal(fs.existsSync(path.join(f.dir,'assets/vendor/three/old-marker')),false);}finally{f.clean();}});
test('Failed vendor request leaves the previous dependency tree intact',()=>{const f=vendorFixture('fail');try{assert.notEqual(f.result.status,0);assert.ok(fs.existsSync(path.join(f.dir,'assets/vendor/three/old-marker')));assert.equal(fs.existsSync(path.join(f.dir,'assets/vendor/three.partial')),false);}finally{f.clean();}});
test('Vendor rejects imports escaping the pinned package',()=>{const f=vendorFixture('escape');try{assert.notEqual(f.result.status,0);assert.ok(fs.existsSync(path.join(f.dir,'assets/vendor/three/old-marker')));}finally{f.clean();}});
