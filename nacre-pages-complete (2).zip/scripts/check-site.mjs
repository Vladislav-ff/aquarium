import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),read=p=>fs.readFileSync(path.join(root,p),'utf8');
const html=read('index.html'),m=JSON.parse(read('asset-manifest.json')),ids=[...html.matchAll(/\bid="([^"]+)"/g)].map(x=>x[1]);
assert.equal(new Set(ids).size,ids.length,'Duplicate DOM IDs');assert.ok(fs.existsSync(path.join(root,'.nojekyll')));
for(const ref of [...html.matchAll(/(?:href|src)="([^"#]+)"/g)].map(x=>x[1])){if(/^https:/.test(ref))continue;assert.ok(ref.startsWith('./'),'Unsafe or root-absolute path '+ref);assert.ok(fs.existsSync(path.join(root,ref.split('?')[0])),'Missing resource '+ref);}
for(const name of Object.values(m.assets)){
 const data=read('assets/'+name),hash=createHash('sha256').update(data).digest('hex').slice(0,12);assert.ok(name.includes('.'+hash+'.'),'Hash mismatch '+name);
 if(name.endsWith('.mjs')){
  for(const x of data.matchAll(/(?:from\s*|import\(\s*)['"](\.\/[^'"]+)['"]/g))assert.ok(fs.existsSync(path.join(root,'assets',x[1])),'Missing import '+x[1]);
  const r=spawnSync(process.execPath,['--check',path.join(root,'assets',name)],{encoding:'utf8'});assert.equal(r.status,0,r.stderr);
 }
}
for(const x of read('assets/'+m.assets.app).matchAll(/\$\('([^']+)'\)/g))assert.ok(ids.includes(x[1]),'Missing DOM ID '+x[1]);
for(const name of fs.readdirSync(path.join(root,'scripts')).filter(x=>x.endsWith('.mjs'))){const r=spawnSync(process.execPath,['--check',path.join(root,'scripts',name)],{encoding:'utf8'});assert.equal(r.status,0,r.stderr);}
assert.equal(JSON.parse(read('manifest.webmanifest')).start_url,'./');assert.equal(JSON.parse(read('manifest.webmanifest')).scope,'./');assert.ok(!html.includes('__STYLES__')&&!html.includes('__BOOT__'));
if(m.localThree){const v=JSON.parse(read('assets/vendor/three/checksums.json'));assert.equal(v.version,'0.169.0');for(const [name,digest] of Object.entries(v.files)){const b=fs.readFileSync(path.join(root,'assets/vendor/three',name));assert.equal(createHash('sha256').update(b).digest('hex'),digest,'Vendor checksum mismatch '+name);}assert.ok(!html.includes('cdn.jsdelivr.net'));}
console.log('PASS: static paths, content hashes, imports, DOM IDs, syntax, manifest and vendor checksums');
