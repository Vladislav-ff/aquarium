import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),out=path.join(root,'site');
await fs.rm(out,{recursive:true,force:true});await fs.mkdir(out,{recursive:true});
for(const f of ['index.html','.nojekyll','404.html','manifest.webmanifest','asset-manifest.json','assets'])await fs.cp(path.join(root,f),path.join(out,f),{recursive:true});
console.log('Deployment-only files staged in site/');
