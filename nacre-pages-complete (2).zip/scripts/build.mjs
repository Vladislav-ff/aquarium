import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const read=name=>fs.readFile(path.join(root,'src',name),'utf8');
const emit=async(stem,ext,text)=>{const digest=createHash('sha256').update(text).digest('hex').slice(0,12),name=`${stem}.${digest}.${ext}`;await fs.writeFile(path.join(root,'assets',name),text);return name;};
await fs.mkdir(path.join(root,'assets'),{recursive:true});
const physics=await emit('physics','mjs',await read('physics.mjs'));
const app=await emit('aquarium','mjs',(await read('aquarium.mjs')).replace("'./physics.mjs'",JSON.stringify('./'+physics)));
const boot=await emit('boot','mjs',(await read('boot.mjs')).replace("'./aquarium.mjs'",JSON.stringify('./'+app)));
const styles=await emit('styles','css',await read('styles.css'));
let html=(await read('index.template.html')).replace('__STYLES__','./assets/'+styles).replace('__BOOT__','./assets/'+boot),localThree=false;
try{localThree=JSON.parse(await fs.readFile(path.join(root,'site-config.json'),'utf8')).localThree===true;}catch(e){if(e.code!=='ENOENT')throw e;}
if(localThree){
 for(const f of ['build/three.module.js','examples/jsm/controls/OrbitControls.js','LICENSE','checksums.json'])await fs.access(path.join(root,'assets/vendor/three',f));
 html=html.replace('https://cdn.jsdelivr.net/npm/three@0.169.0/build/three.module.js','./assets/vendor/three/build/three.module.js').replace('https://cdn.jsdelivr.net/npm/three@0.169.0/examples/jsm/','./assets/vendor/three/examples/jsm/').replace('<link rel="preconnect" href="https://cdn.jsdelivr.net" crossorigin>','');
}
// Do not purge older content-addressed assets: cached HTML may still reference them.
await fs.writeFile(path.join(root,'index.html'),html);
await fs.writeFile(path.join(root,'asset-manifest.json'),JSON.stringify({version:'4.2.0',source:'supplied NACRE IV',three:'0.169.0',localThree,assets:{physics,app,boot,styles}},null,2)+'\n');
console.log('Static Pages site built; localThree='+localThree);
