const $=id=>document.getElementById(id);
let ready=false,failed=false;
function showFailure(message){failed=true;const loader=$('loader');if(!loader)return;loader.style.display='flex';loader.style.opacity='1';$('loadingText').textContent=String(message||'Ошибка загрузки');loader.querySelector('.loadline').hidden=true;$('startupActions').hidden=false;$('startupStatus').textContent='Сцена не запущена';}
window.aquariumFail=showFailure;
$('retry').addEventListener('click',()=>location.reload());
$('retryLow').addEventListener('click',()=>{const url=new URL(location.href);url.searchParams.set('quality','low');location.assign(url);});
window.addEventListener('nacre:ready',()=>{ready=true;failed=false;clearTimeout(window.loadTimer);$('startupStatus').textContent='Сцена загружена';});
window.addEventListener('error',e=>{if(!ready)showFailure('Ошибка запуска: '+(e.message||'ресурс недоступен'));});
window.addEventListener('unhandledrejection',e=>{console.error('NACRE:',e.reason);if(!ready)showFailure('Ошибка запуска: '+String(e.reason?.message||e.reason));});
window.loadTimer=setTimeout(()=>{if(!ready)showFailure('Загрузка заняла слишком много времени. Проверьте доступ к библиотекам и повторите запуск.');},25000);
if(location.protocol==='file:'){clearTimeout(window.loadTimer);showFailure('Нужен HTTP-сервер: python -m http.server 8000, затем localhost:8000. Или откройте сайт GitHub Pages.');}
else{try{await import("./aquarium.ec3dbb86b1e3.mjs");if(!window.aquariumReady&&!failed)showFailure('Сцена не сообщила о готовности.');}catch(error){clearTimeout(window.loadTimer);console.error('NACRE startup:',error);showFailure('Не удалось загрузить 3D. Проверьте поддержку WebGL 2 и доступ к Three.js. Повторите запуск или выберите экономичный режим.');}}
